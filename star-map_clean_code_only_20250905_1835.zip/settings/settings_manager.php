<?php
/**
 * Settings Manager PHP Script for Star Map Generator
 * 
 * This script handles storing and retrieving settings data for the Star Map Generator application.
 * It supports both GET (retrieve) and POST (save) operations.
 * 
 * GET: Retrieves settings data
 * POST: Saves settings data
 * 
 * Data is stored in a JSON file in the current directory.
 */

// Set appropriate headers
header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

// Create error log file for debugging
$errorLogFile = __DIR__ . '/php_errorlog';
error_log("Settings Manager PHP Script started.");

// Handle CORS if needed
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle OPTIONS request (for CORS preflight)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// Settings file path
$settingsFilePath = __DIR__ . '/settings.json';

// Handle GET request (retrieve settings)
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    error_log("GET request received for settings");

    if (!file_exists($settingsFilePath)) {
        error_log("Settings file not found: $settingsFilePath");
        http_response_code(404);
        echo json_encode(['success' => false, 'message' => 'No settings file found']);
        exit;
    }

    $data = file_get_contents($settingsFilePath);
    if ($data === false) {
        error_log("Error reading settings file: $settingsFilePath");
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Error reading settings file']);
        exit;
    }

    // Return the raw JSON data
    echo $data;
    exit;
}

// Handle POST request (save settings)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    error_log("POST request received for settings");
    
    // Get JSON data from request body
    $jsonData = file_get_contents('php://input');
    error_log("Request body length: " . strlen($jsonData));
    
    $data = json_decode($jsonData, true);
    
    if (!$data) {
        error_log("Failed to decode JSON: " . json_last_error_msg());
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid JSON data']);
        exit;
    }

    // Save data to file
    $result = file_put_contents($settingsFilePath, $jsonData);

    if ($result === false) {
        error_log("Failed to write to settings file: $settingsFilePath");
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'Error saving settings data']);
        exit;
    }

    error_log("Successfully saved settings data to file: $settingsFilePath (" . $result . " bytes)");
    echo json_encode(['success' => true, 'message' => 'Settings saved successfully']);
    exit;
}

// Handle unsupported request methods
http_response_code(405);
echo json_encode(['success' => false, 'message' => 'Method not allowed']);
exit;
