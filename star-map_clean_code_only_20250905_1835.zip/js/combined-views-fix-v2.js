/* Combined Views Fix v2 - 2025-06-01 11:45 AM */

/**
 * This script focuses specifically on fixing the combined views (landscape and portrait).
 * It addresses the following issues:
 * 1. Canvas dimensions not updating correctly
 * 2. Text overlays disappearing
 * 3. Random elements appearing
 * 4. Modal dialog issues
 * 5. Paper size selection handling
 */

(function() {
    console.log('Combined Views Fix v2 - Initializing');
    
    // Store captured images
    let starMapImage = null;
    let streetMapImage = null;
    
    // Flag to prevent recursive calls
    let isProcessing = false;
    
    // -------------------------------------------------------------------------
    // Core Functions
    // -------------------------------------------------------------------------
    
    // Remove any existing dimensions display
    function removeExistingDimensionsDisplay() {
        document.querySelectorAll('[id^="canvas-dimensions"], .canvas-dimensions-display').forEach(el => {
            if (el.parentNode) el.parentNode.removeChild(el);
        });
        
        document.querySelectorAll('div, p, span').forEach(el => {
            if (el.textContent && (el.textContent.includes('Canvas Dimensions') || 
                                  el.textContent.includes('Dimensions:')) && 
                !el.classList.contains('canvas-container')) {
                if (el.parentNode) el.parentNode.removeChild(el);
            }
        });
    }
    
    // Update canvas dimensions display
    function updateDimensionsDisplay(width, height) {
        removeExistingDimensionsDisplay();
        
        const dimensionsDisplay = document.createElement('div');
        dimensionsDisplay.id = 'canvas-dimensions-display';
        dimensionsDisplay.style.cssText = `
            text-align: center;
            font-weight: bold;
            color: #0056b3;
            margin: 10px 0;
            padding: 5px;
            background-color: #f8f9fa;
            border-radius: 5px;
            width: 100%;
            z-index: 9999;
        `;
        
        const zoomContainer = document.getElementById('zoom-container');
        if (zoomContainer && zoomContainer.parentNode) {
            zoomContainer.parentNode.insertBefore(dimensionsDisplay, zoomContainer.nextSibling);
        } else {
            document.body.appendChild(dimensionsDisplay);
        }
        
        // Format dimensions text
        let dimensionsText;
        const paperSizeSelect = document.getElementById('paper-auto-size');
        if (paperSizeSelect && paperSizeSelect.value && 
            paperSizeSelect.value !== 'default' && 
            paperSizeSelect.value !== 'Select A Paper Size...') {
            const paperSize = paperSizeSelect.value;
            const dpi = document.getElementById('dpi')?.value || '300';
            dimensionsText = `Paper: ${paperSize} | DPI: ${dpi} | Dimensions: ${width}w x ${height}h pixels`;
        } else {
            dimensionsText = `Dimensions: ${width}w x ${height}h pixels`;
        }
        
        dimensionsDisplay.textContent = dimensionsText;
    }
    
    // Handle modal dialogs
    function handleModal() {
        document.querySelectorAll('.modal, .custom-alert, .custom-modal').forEach(modal => {
            const okButton = modal.querySelector('button, .ok-button, .btn-primary');
            if (okButton) okButton.click();
            if (modal.parentNode) modal.parentNode.removeChild(modal);
        });
        
        document.querySelectorAll('div, p, span').forEach(el => {
            if (el.textContent && el.textContent.includes('Computing star map')) {
                if (el.parentNode) el.parentNode.removeChild(el);
            }
        });
    }
    
    // Get user dimensions
    function getUserDimensions() {
        const widthInput = document.getElementById('width');
        const heightInput = document.getElementById('height');
        
        let width = 2550, height = 3300;
        if (widthInput && heightInput && widthInput.value && heightInput.value) {
            width = parseInt(widthInput.value);
            height = parseInt(heightInput.value);
        }
        
        return { width, height };
    }
    
    // Capture images
    function captureImages() {
        // Capture star map image
        const starMapImg = document.querySelector('.star-map-circle img');
        if (starMapImg) {
            const newImg = new Image();
            newImg.crossOrigin = "Anonymous";
            newImg.onload = function() { starMapImage = newImg; };
            newImg.src = starMapImg.src;
        }
        
        // Capture street map image
        const streetMapImg = document.querySelector('.street-map-circle img');
        if (streetMapImg) {
            const newImg = new Image();
            newImg.crossOrigin = "Anonymous";
            newImg.onload = function() { streetMapImage = newImg; };
            newImg.src = streetMapImg.src;
        }
    }
    
    // Capture text overlays
    function captureTextOverlays() {
        // Store original text overlays
        window.savedTextOverlays = {
            title: document.querySelector('.title-text'),
            date: document.querySelector('.date-text'),
            quote: document.querySelector('.quote-text'),
            location: document.querySelector('.location-text'),
            coordinates: document.querySelector('.coordinates-text'),
            footer: document.querySelector('.footer-text')
        };
    }
    
    // Restore text overlays
    function restoreTextOverlays() {
        if (!window.savedTextOverlays) return;
        
        // Find the canvas container
        const canvasContainer = document.querySelector('.canvas-container');
        if (!canvasContainer) return;
        
        // Remove any existing text overlays
        document.querySelectorAll('.title-text, .date-text, .quote-text, .location-text, .coordinates-text, .footer-text').forEach(el => {
            if (el.parentNode) el.parentNode.removeChild(el);
        });
        
        // Restore each text overlay
        Object.entries(window.savedTextOverlays).forEach(([key, element]) => {
            if (element) {
                const clone = element.cloneNode(true);
                clone.style.display = 'block';
                clone.style.visibility = 'visible';
                clone.style.opacity = '1';
                canvasContainer.appendChild(clone);
            }
        });
    }
    
    // -------------------------------------------------------------------------
    // Combined View Functions
    // -------------------------------------------------------------------------
    
    // Draw combined landscape view
    function drawCombinedLandscapeView() {
        if (isProcessing) return;
        isProcessing = true;
        
        try {
            handleModal();
            
            // Check if we have both images
            if (!starMapImage || !streetMapImage) {
                // Generate star map if needed
                if (!starMapImage) {
                    const starMapBtn = document.getElementById('view-star-map-btn');
                    if (starMapBtn) {
                        starMapBtn.click();
                        captureTextOverlays();
                    }
                }
                
                // Generate street map if needed
                if (!streetMapImage) {
                    const streetMapBtn = document.getElementById('view-street-map-btn');
                    if (streetMapBtn) streetMapBtn.click();
                }
                
                // Try again after a delay
                setTimeout(() => {
                    isProcessing = false;
                    captureImages();
                    drawCombinedLandscapeView();
                }, 1000);
                return;
            }
            
            // Get canvas
            const canvas = document.getElementById('star-map-canvas');
            if (!canvas) {
                isProcessing = false;
                return;
            }
            
            const ctx = canvas.getContext('2d');
            
            // Get dimensions - ensure landscape (width > height)
            const dimensions = getUserDimensions();
            let width = dimensions.width;
            let height = dimensions.height;
            
            if (width < height) {
                [width, height] = [height, width];
            }
            
            // Set canvas dimensions
            canvas.width = width;
            canvas.height = height;
            
            // Get settings
            const bgColor = document.getElementById('bg-color-canvas')?.value || '#1D1D4D';
            const borderColor = document.getElementById('border-color')?.value || '#FDCA0D';
            const borderWidth = parseInt(document.getElementById('border-width')?.value) || 2;
            const radiusPercent = parseInt(document.getElementById('circle-radius-percent')?.value) || 60;
            
            // Calculate positions
            const smallerDim = Math.min(width, height);
            const radius = (smallerDim * radiusPercent) / 200;
            
            const leftCenter = { x: width * 0.3, y: height * 0.5, radius: radius };
            const rightCenter = { x: width * 0.7, y: height * 0.5, radius: radius };
            
            // Clear canvas
            ctx.fillStyle = bgColor;
            ctx.fillRect(0, 0, width, height);
            
            // Draw maps in circles
            function drawCircleImage(img, center) {
                if (!img) return;
                
                ctx.save();
                ctx.beginPath();
                ctx.arc(center.x, center.y, center.radius, 0, Math.PI * 2);
                ctx.clip();
                
                const imgWidth = img.naturalWidth || img.width;
                const imgHeight = img.naturalHeight || img.height;
                const scale = Math.max(center.radius * 2 / imgWidth, center.radius * 2 / imgHeight);
                
                const scaledWidth = imgWidth * scale;
                const scaledHeight = imgHeight * scale;
                const x = center.x - (scaledWidth / 2);
                const y = center.y - (scaledHeight / 2);
                
                ctx.drawImage(img, x, y, scaledWidth, scaledHeight);
                ctx.restore();
                
                ctx.strokeStyle = borderColor;
                ctx.lineWidth = borderWidth;
                ctx.beginPath();
                ctx.arc(center.x, center.y, center.radius, 0, Math.PI * 2);
                ctx.stroke();
            }
            
            // Draw in correct order
            const streetMapFirst = document.querySelector('input[name="map-order"][value="street-first"]')?.checked !== false;
            if (streetMapFirst) {
                drawCircleImage(streetMapImage, leftCenter);
                drawCircleImage(starMapImage, rightCenter);
            } else {
                drawCircleImage(starMapImage, leftCenter);
                drawCircleImage(streetMapImage, rightCenter);
            }
            
            // Fix canvas styling
            canvas.style.height = 'auto';
            canvas.style.maxHeight = '70vh';
            canvas.style.width = 'auto';
            canvas.style.maxWidth = '100%';
            canvas.style.display = 'block';
            canvas.style.margin = '0 auto';
            
            // Update dimensions display
            updateDimensionsDisplay(width, height);
            
            // Restore text overlays
            restoreTextOverlays();
            
        } catch (error) {
            console.error('Error in combined landscape view:', error);
        } finally {
            handleModal();
            isProcessing = false;
        }
    }
    
    // Draw combined portrait view
    function drawCombinedPortraitView() {
        if (isProcessing) return;
        isProcessing = true;
        
        try {
            handleModal();
            
            // Check if we have both images
            if (!starMapImage || !streetMapImage) {
                // Generate star map if needed
                if (!starMapImage) {
                    const starMapBtn = document.getElementById('view-star-map-btn');
                    if (starMapBtn) {
                        starMapBtn.click();
                        captureTextOverlays();
                    }
                }
                
                // Generate street map if needed
                if (!streetMapImage) {
                    const streetMapBtn = document.getElementById('view-street-map-btn');
                    if (streetMapBtn) streetMapBtn.click();
                }
                
                // Try again after a delay
                setTimeout(() => {
                    isProcessing = false;
                    captureImages();
                    drawCombinedPortraitView();
                }, 1000);
                return;
            }
            
            // Get canvas
            const canvas = document.getElementById('star-map-canvas');
            if (!canvas) {
                isProcessing = false;
                return;
            }
            
            const ctx = canvas.getContext('2d');
            
            // Get dimensions - ensure portrait (height > width)
            const dimensions = getUserDimensions();
            let width = dimensions.width;
            let height = dimensions.height;
            
            if (height < width) {
                [width, height] = [height, width];
            }
            
            // Set canvas dimensions
            canvas.width = width;
            canvas.height = height;
            
            // Get settings
            const bgColor = document.getElementById('bg-color-canvas')?.value || '#1D1D4D';
            const borderColor = document.getElementById('border-color')?.value || '#FDCA0D';
            const borderWidth = parseInt(document.getElementById('border-width')?.value) || 2;
            const radiusPercent = parseInt(document.getElementById('circle-radius-percent')?.value) || 60;
            
            // Calculate positions
            const smallerDim = Math.min(width, height);
            const radius = (smallerDim * radiusPercent) / 200;
            
            const topCenter = { x: width * 0.5, y: height * 0.3, radius: radius };
            const bottomCenter = { x: width * 0.5, y: height * 0.7, radius: radius };
            
            // Clear canvas
            ctx.fillStyle = bgColor;
            ctx.fillRect(0, 0, width, height);
            
            // Draw maps in circles
            function drawCircleImage(img, center) {
                if (!img) return;
                
                ctx.save();
                ctx.beginPath();
                ctx.arc(center.x, center.y, center.radius, 0, Math.PI * 2);
                ctx.clip();
                
                const imgWidth = img.naturalWidth || img.width;
                const imgHeight = img.naturalHeight || img.height;
                const scale = Math.max(center.radius * 2 / imgWidth, center.radius * 2 / imgHeight);
                
                const scaledWidth = imgWidth * scale;
                const scaledHeight = imgHeight * scale;
                const x = center.x - (scaledWidth / 2);
                const y = center.y - (scaledHeight / 2);
                
                ctx.drawImage(img, x, y, scaledWidth, scaledHeight);
                ctx.restore();
                
                ctx.strokeStyle = borderColor;
                ctx.lineWidth = borderWidth;
                ctx.beginPath();
                ctx.arc(center.x, center.y, center.radius, 0, Math.PI * 2);
                ctx.stroke();
            }
            
            // Draw in correct order
            const streetMapFirst = document.querySelector('input[name="map-order"][value="street-first"]')?.checked !== false;
            if (streetMapFirst) {
                drawCircleImage(streetMapImage, topCenter);
                drawCircleImage(starMapImage, bottomCenter);
            } else {
                drawCircleImage(starMapImage, topCenter);
                drawCircleImage(streetMapImage, bottomCenter);
            }
            
            // Fix canvas styling
            canvas.style.height = 'auto';
            canvas.style.maxHeight = '70vh';
            canvas.style.width = 'auto';
            canvas.style.maxWidth = '100%';
            canvas.style.display = 'block';
            canvas.style.margin = '0 auto';
            
            // Update dimensions display
            updateDimensionsDisplay(width, height);
            
            // Restore text overlays
            restoreTextOverlays();
            
        } catch (error) {
            console.error('Error in combined portrait view:', error);
        } finally {
            handleModal();
            isProcessing = false;
        }
    }
    
    // -------------------------------------------------------------------------
    // Hook into existing functionality
    // -------------------------------------------------------------------------
    
    // Replace combined landscape view function
    window.viewStarStreetLandscape = drawCombinedLandscapeView;
    
    // Replace combined portrait view function
    window.viewStarStreetPortrait = drawCombinedPortraitView;
    
    // Capture images when star map is generated
    const originalViewStarMap = window.viewStarMap;
    if (originalViewStarMap) {
        window.viewStarMap = function() {
            // Call original function
            originalViewStarMap.apply(this, arguments);
            
            // After a delay to ensure the image is loaded
            setTimeout(() => {
                handleModal();
                captureImages();
                captureTextOverlays();
            }, 500);
        };
    }
    
    // Capture images when street map is generated
    const originalViewStreetMap = window.viewStreetMap;
    if (originalViewStreetMap) {
        window.viewStreetMap = function() {
            // Call original function
            originalViewStreetMap.apply(this, arguments);
            
            // After a delay to ensure the image is loaded
            setTimeout(() => {
                handleModal();
                captureImages();
            }, 500);
        };
    }
    
    // Listen for paper size changes
    const paperSizeSelect = document.getElementById('paper-auto-size');
    if (paperSizeSelect) {
        paperSizeSelect.addEventListener('change', function() {
            const dimensions = getUserDimensions();
            updateDimensionsDisplay(dimensions.width, dimensions.height);
        });
    }
    
    // Listen for width and height changes
    const widthInput = document.getElementById('width');
    const heightInput = document.getElementById('height');
    
    if (widthInput) {
        widthInput.addEventListener('change', function() {
            const dimensions = getUserDimensions();
            updateDimensionsDisplay(dimensions.width, dimensions.height);
        });
    }
    
    if (heightInput) {
        heightInput.addEventListener('change', function() {
            const dimensions = getUserDimensions();
            updateDimensionsDisplay(dimensions.width, dimensions.height);
        });
    }
    
    // Initialize
    captureImages();
    captureTextOverlays();
    
    // Set up a periodic check for modals
    setInterval(handleModal, 1000);
    
    console.log('Combined Views Fix v2 - Initialized');
})();
